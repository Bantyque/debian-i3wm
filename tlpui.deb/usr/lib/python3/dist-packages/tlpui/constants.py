ICON_NAME_WARNING = "dialog-warning"
ICON_NAME_INFO = "dialog-information"
ICON_NAME_UNDO = "edit-undo"
